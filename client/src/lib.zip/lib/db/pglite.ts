// src/lib/db/pglite.ts
import { PGlite } from '@electric-sql/pglite';
import { electricSync } from '@electric-sql/pglite-sync';

declare global {
  interface ImportMetaEnv {
    readonly VITE_ELECTRIC_SHAPE_URL: string;
    readonly VITE_ELECTRIC_SOURCE_ID: string;
    readonly VITE_ELECTRIC_SECRET: string;
  }
}

// pull in your .env vars
const SHAPE_URL     = import.meta.env.VITE_ELECTRIC_SHAPE_URL!;
const SOURCE_ID     = import.meta.env.VITE_ELECTRIC_SOURCE_ID!;
const SOURCE_SECRET = import.meta.env.VITE_ELECTRIC_SECRET!;

// relative path to where the pglite package emits its WASM/data
const DIST_PATH = '../node_modules/@electric-sql/pglite/dist';

let db: PGlite | null = null;
let initPromise: Promise<PGlite> | null = null;

export function initLocalDb(): Promise<PGlite> {
  if (db) return Promise.resolve(db);
  if (initPromise) return initPromise;

  initPromise = (async () => {
    if (!SHAPE_URL || !SOURCE_ID || !SOURCE_SECRET) {
      throw new Error('Missing Electric-SQL config in client/.env');
    }

    const pdb = await PGlite.create({
      dataDir: 'idb://showmedb',
      // tell PGlite where to load its .wasm/.data bundles
      locateFile: (file: string) => {
        if (file.endsWith('.wasm') || file.endsWith('.data')) {
          return new URL(`${DIST_PATH}/${file}`, import.meta.url).href;
        }
        return file;
      },
      extensions: { electric: electricSync() },
    });

    // create your tables
    await pdb.exec(`
      CREATE TABLE IF NOT EXISTS maps (
        id           TEXT PRIMARY KEY,
        name         TEXT NOT NULL,
        is_private   TEXT NOT NULL DEFAULT 'false',
        access_token TEXT,
        created_at   TEXT NOT NULL
      );
    `);
    await pdb.exec(`
      CREATE TABLE IF NOT EXISTS pins (
        id           TEXT PRIMARY KEY,
        map_id       TEXT NOT NULL,
        lat          REAL NOT NULL,
        lng          REAL NOT NULL,
        tags         TEXT,
        description  TEXT,
        photo_urls   TEXT,
        created_at   TEXT NOT NULL,
        updated_at   TEXT NOT NULL
      );
    `);

    // sync shapes with a shapeKey so you only ever load once
    await Promise.all([
      pdb.electric.syncShapeToTable({
        shape: {
          url: SHAPE_URL,
          params: {
            table:     'maps',
            source_id: SOURCE_ID,
            secret:    SOURCE_SECRET
          }
        },
        table:      'maps',
        primaryKey: ['id'],
        shapeKey:   'maps',
        initialInsertMethod: 'json'
      }),
      pdb.electric.syncShapeToTable({
        shape: {
          url: SHAPE_URL,
          params: {
            table:     'pins',
            source_id: SOURCE_ID,
            secret:    SOURCE_SECRET
          }
        },
        table:      'pins',
        primaryKey: ['id'],
        shapeKey:   'pins',
        initialInsertMethod: 'json'
      })
    ]);

    db = pdb;
    return pdb;
  })();

  return initPromise;
}
