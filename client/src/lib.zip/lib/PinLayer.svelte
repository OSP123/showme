<script lang="ts">
    import { onDestroy } from 'svelte';
    import { Marker } from 'maplibre-gl';
    import type { Map as GLMap } from 'maplibre-gl';
    import type { PinRow } from '$lib/models';
    import { initLocalDb } from '$lib/db/pglite';
  
    export let map: GLMap;
    export let mapId: string;
  
    let markers: Marker[] = [];
    let streamUnsub: () => void;
  
    async function drawPins() {
      const db = await initLocalDb();
      const { rows } = await db.query<{ rows: PinRow[] }>(
        `SELECT * FROM pins WHERE map_id=$1 ORDER BY created_at`, [mapId]
      );
      // clear
      markers.forEach((m) => m.remove());
      markers = [];
      rows.forEach(pin => {
        const m = new Marker({ color: 'red' })
          .setLngLat([pin.lng, pin.lat])
          .addTo(map);
        markers.push(m);
      });
    }
  
    onDestroy(() => {
      if (streamUnsub) streamUnsub();
    });
  
    $: if (map && mapId) {
      // initial draw
      drawPins();
  
      // sync
      (async () => {
        const db = await initLocalDb();
        const stream = await db.electric.syncShapeToTable({
          shape: {
            url: import.meta.env.VITE_ELECTRIC_SHAPE_URL,
            params: {
              table: 'pins',
              where: `map_id=${mapId}`,
              source_id: import.meta.env.VITE_ELECTRIC_SOURCE_ID,
              secret:    import.meta.env.VITE_ELECTRIC_SECRET
            }
          },
          table: 'pins',
          primaryKey: ['id'],
          shapeKey:  `pins_${mapId}`,
          initialInsertMethod: 'json'
        });
        streamUnsub = stream.subscribe(drawPins);
      })();
    }
  </script>
  